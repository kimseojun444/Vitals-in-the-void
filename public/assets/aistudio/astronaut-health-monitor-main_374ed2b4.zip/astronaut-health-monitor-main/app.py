
import streamlit as st
import streamlit.components.v1 as components
from streamlit_webrtc import webrtc_streamer, WebRtcMode, AudioProcessorBase
import av
import numpy as np
import queue
import threading
import tempfile
import time
import soundfile as sf
from pathlib import Path

from assistant.conversation import process_message, start_conversation
from assistant.voice_input import transcribe_audio
from assistant.voice_output import speak


st.set_page_config(page_title="TARS | V²", page_icon="🐈", layout="centered")

st.markdown("""
<style>
.stApp { background: #080d18; color: #e8f0ff; }
.block-container { max-width: 650px; padding-top: 2rem; }
.tars-title { text-align:center; font-size:48px; font-weight:700;
letter-spacing:5px; color:#e8f0ff; }
.tars-subtitle { text-align:center; color:#9eacc4; }
.tars-cat { text-align:center; font-size:100px; margin:25px; }
</style>
""", unsafe_allow_html=True)

st.markdown('<div class="tars-title">TARS</div>', unsafe_allow_html=True)
st.markdown('<div class="tars-subtitle">Your companion among the stars.</div>', unsafe_allow_html=True)
st.markdown('<div class="tars-cat">🐈‍⬛</div>', unsafe_allow_html=True)

if "tars_status" not in st.session_state:
    st.session_state.tars_status = "Waiting for connection"

if "tars_reply" not in st.session_state:
    st.session_state.tars_reply = ""

if "tars_audio" not in st.session_state:
    st.session_state.tars_audio = None

if "tars_greeted" not in st.session_state:
    st.session_state.tars_greeted = False

audio_queue = queue.Queue()
reply_queue = queue.Queue()


class TarsAudioProcessor(AudioProcessorBase):
    def __init__(self):
        self.frames = []
        self.speaking = False
        self.silence = 0.0
        self.last_rate = 48000

    def recv(self, frame: av.AudioFrame) -> av.AudioFrame:
        audio = frame.to_ndarray()
        channels = len(frame.layout.channels)

        if audio.ndim == 2:
            if audio.shape[0] == channels:
                audio = audio.mean(axis=0)
            elif audio.shape[1] == channels:
                audio = audio.mean(axis=1)

        audio = audio.reshape(-1).astype(np.float32)

        if np.issubdtype(frame.to_ndarray().dtype, np.integer):
            audio = audio / 32768.0

        rate = frame.sample_rate or 48000
        self.last_rate = rate

        rms = float(np.sqrt(np.mean(audio ** 2))) if len(audio) else 0

        if rms > 0.015:
            self.speaking = True
            self.silence = 0
            self.frames.append(audio)
        elif self.speaking:
            self.frames.append(audio)
            self.silence += len(audio) / rate

        if self.speaking and self.silence >= 1.0:
            recording = np.concatenate(self.frames)
            self.frames = []
            self.speaking = False
            self.silence = 0

            if len(recording) > rate * 0.4:
                audio_queue.put((recording, rate))

        return frame


def process_audio():
    while True:
        recording, rate = audio_queue.get()

        try:
            with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
                path = Path(f.name)

            sf.write(str(path), recording, rate)

            result = transcribe_audio(str(path))
            path.unlink(missing_ok=True)

            spoken_text = result["text"].strip()

            if not spoken_text:
                continue

            answer = process_message(spoken_text)
            audio_path = speak(answer)

            audio_bytes = audio_path.read_bytes() if audio_path else None

            if audio_path:
                audio_path.unlink(missing_ok=True)

            reply_queue.put((spoken_text, answer, audio_bytes))

        except Exception as error:
            reply_queue.put(("", f"TARS encountered an error: {error}", None))


if "tars_worker_started" not in st.session_state:
    threading.Thread(target=process_audio, daemon=True).start()
    st.session_state.tars_worker_started = True

st.markdown("### Your conversation")
st.caption("Allow microphone access, then speak naturally.")

ctx = webrtc_streamer(
    key="tars-live",
    mode=WebRtcMode.SENDONLY,
    audio_processor_factory=TarsAudioProcessor,
    media_stream_constraints={
        "video": False,
        "audio": {
            "echoCancellation": True,
            "noiseSuppression": True,
            "autoGainControl": True
        }
    },
    rtc_configuration={
        "iceServers": [{"urls": ["stun:stun.l.google.com:19302"]}]
    },
)

while not reply_queue.empty():
    spoken_text, answer, audio_bytes = reply_queue.get_nowait()
    st.session_state.tars_reply = answer
    st.session_state.tars_audio = audio_bytes
    st.session_state.tars_status = "TARS replied"

if ctx.state.playing:
    st.success("Microphone connected")
    if not st.session_state.tars_greeted:
        st.session_state.tars_reply = start_conversation()
        st.session_state.tars_greeted = True
        try:
            greeting_path = speak(st.session_state.tars_reply)
            if greeting_path:
                st.session_state.tars_audio = greeting_path.read_bytes()
                greeting_path.unlink(missing_ok=True)
        except Exception as error:
            st.error(f"Voice error: {error}")

if st.session_state.tars_reply:
    st.markdown("**TARS:**")
    st.write(st.session_state.tars_reply)

if st.session_state.tars_audio:
    st.audio(st.session_state.tars_audio, format="audio/wav", autoplay=True)
