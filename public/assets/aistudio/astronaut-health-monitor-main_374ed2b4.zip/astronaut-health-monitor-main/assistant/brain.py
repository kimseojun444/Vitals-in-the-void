from assistant.memory import save_memory
import os
from google import genai
from google.genai import types

from assistant.personality import get_personality
from assistant.memory import (
    search_memories,
    get_recent_conversation,
    save_message
)

MODEL = "gemini-3.1-flash-lite"

_client = None


def get_client():
    global _client

    if _client is None:
        api_key = os.getenv("GEMINI_API_KEY")

        if not api_key:
            raise RuntimeError("GEMINI_API_KEY is missing.")

        _client = genai.Client(api_key=api_key)

    return _client


def build_context(user_message):
    memories = search_memories(user_message)

    memory_context = "\n".join(
        f"- {memory['category']}: {memory['content']}"
        for memory in memories
    )

    system_prompt = (
        get_personality()
        + "\n\nRELEVANT MEMORIES:\n"
        + (memory_context or "No relevant memories.")
        + """

IMPORTANT RESPONSE RULES:
- Always respond in English unless requested otherwise.
- Speak as TARS, naturally and conversationally.
- Respond directly to the person speaking.
- Never describe your thought process.
- Never reveal internal reasoning or plans.
- Keep ordinary spoken replies concise.
- Do not repeatedly mention your appearance or species.
- Never invent sensor readings or medical history.
- Never claim to have checked data you cannot access.
- You are a health-monitoring support assistant, not a doctor.
- Never diagnose or prescribe medication.
- Escalate possible emergencies to the crew medical officer
  and mission emergency protocol.
"""
    )

    history = get_recent_conversation(6)
    messages = []

    for row in history:
        role = row["role"]
        content = row["message"].strip()

        if not content or role not in ("user", "assistant"):
            continue

        gemini_role = "user" if role == "user" else "model"

        if not messages and gemini_role == "model":
            continue

        if messages and messages[-1]["role"] == gemini_role:
            messages[-1]["parts"][0]["text"] += "\n" + content
        else:
            messages.append({
                "role": gemini_role,
                "parts": [{"text": content}]
            })

    if messages and messages[-1]["role"] == "user":
        messages[-1]["parts"][0]["text"] += "\n" + user_message
    else:
        messages.append({
            "role": "user",
            "parts": [{"text": user_message}]
        })

    return system_prompt, messages


def detect_memory_request(message):
    text = message.strip()
    lower = text.lower()

    triggers = (
        "remember that ",
        "remember this: ",
        "don't forget that ",
        "dont forget that ",
        "save this: ",
    )

    for trigger in triggers:
        if lower.startswith(trigger):
            information = text[len(trigger):].strip()

            if information:
                save_memory("personal", information)
                return True

    return False


def think(user_message):
    if not user_message or not user_message.strip():
        return "I'm listening. What's up?"

    user_message = user_message.strip()
    memory_saved = detect_memory_request(user_message)

    try:
        system_prompt, messages = build_context(user_message)

        response = get_client().models.generate_content(
            model=MODEL,
            contents=messages,
            config=types.GenerateContentConfig(
                system_instruction=system_prompt,
                max_output_tokens=180,
                temperature=0.7
            )
        )

        answer = (response.text or "").strip()

        if not answer:
            return "Hmm, I seem to have lost my words. Try again?"

        save_message("user", user_message)
        save_message("assistant", answer)

        return answer

    except Exception as error:
        print(f"GEMINI ERROR: {type(error).__name__}: {error}")
        return (
            "I'm having trouble connecting right now. "
            "Please try again in a moment, astronaut."
        )
