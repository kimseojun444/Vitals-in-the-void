
import sqlite3
import re
from pathlib import Path
from datetime import datetime

DB_PATH = Path(__file__).parent / "tars_memory.db"

STOPWORDS = {
    "what", "is", "the", "my", "your", "a", "an", "and",
    "or", "to", "of", "in", "on", "for", "do", "does",
    "can", "you", "i", "me", "about", "tell", "remember",
    "that", "this", "please", "know", "have", "has"
}


def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def initialize_memory():
    with get_connection() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS memories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                category TEXT NOT NULL,
                content TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
        """)

        conn.execute("""
            CREATE TABLE IF NOT EXISTS conversations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                role TEXT NOT NULL,
                message TEXT NOT NULL,
                timestamp TEXT NOT NULL
            )
        """)


def tokenize(text):
    words = re.findall(r"\b[a-zA-Z0-9]+\b", text.lower())
    return {word for word in words if word not in STOPWORDS}


def save_memory(category, content):
    category = category.strip()
    content = content.strip()

    if not category or not content:
        return False

    with get_connection() as conn:
        existing = conn.execute(
            """
            SELECT id FROM memories
            WHERE LOWER(category) = LOWER(?)
            AND LOWER(content) = LOWER(?)
            LIMIT 1
            """,
            (category, content)
        ).fetchone()

        if existing:
            return False

        conn.execute(
            """
            INSERT INTO memories (category, content, created_at)
            VALUES (?, ?, ?)
            """,
            (category, content, datetime.now().isoformat())
        )

    return True


def search_memories(query, limit=10):
    query_words = tokenize(query)

    if not query_words:
        return []

    with get_connection() as conn:
        rows = conn.execute(
            "SELECT * FROM memories ORDER BY id DESC LIMIT 500"
        ).fetchall()

    scored = []

    for row in rows:
        content_words = tokenize(row["content"])
        category_words = tokenize(row["category"])

        matches = query_words.intersection(
            content_words | category_words
        )

        if matches:
            score = len(matches) / len(query_words)

            scored.append((score, row))

    scored.sort(
        key=lambda item: (item[0], item[1]["id"]),
        reverse=True
    )

    return [row for score, row in scored[:limit]]


def get_all_memories(limit=50):
    with get_connection() as conn:
        return conn.execute(
            "SELECT * FROM memories ORDER BY id DESC LIMIT ?",
            (limit,)
        ).fetchall()


def save_message(role, message):
    if role not in ("user", "assistant"):
        return False

    if not message or not message.strip():
        return False

    with get_connection() as conn:
        conn.execute(
            """
            INSERT INTO conversations (role, message, timestamp)
            VALUES (?, ?, ?)
            """,
            (role, message.strip(), datetime.now().isoformat())
        )

    return True


def get_recent_conversation(limit=20):
    with get_connection() as conn:
        rows = conn.execute(
            """
            SELECT role, message
            FROM conversations
            ORDER BY id DESC
            LIMIT ?
            """,
            (limit,)
        ).fetchall()

    return list(reversed(rows))


def clear_conversation_history():
    with get_connection() as conn:
        conn.execute("DELETE FROM conversations")


def clear_all_memories():
    with get_connection() as conn:
        conn.execute("DELETE FROM memories")


initialize_memory()
