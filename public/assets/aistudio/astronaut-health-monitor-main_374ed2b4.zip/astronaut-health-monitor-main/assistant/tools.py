
from datetime import datetime
from assistant.memory import (
    get_connection,
    save_memory,
    search_memories
)


def initialize_tools():
    with get_connection() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS reminders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                description TEXT NOT NULL,
                due_at TEXT,
                completed INTEGER DEFAULT 0,
                created_at TEXT NOT NULL
            )
        """)


def save_note(note, category="note"):
    if not note or not note.strip():
        return False

    return save_memory(category, note.strip())


def find_information(query, limit=10):
    if not query or not query.strip():
        return []

    return [
        dict(row)
        for row in search_memories(query.strip(), limit=limit)
    ]


def create_reminder(description, due_at=None):
    if not description or not description.strip():
        return None

    if due_at:
        try:
            datetime.fromisoformat(due_at)
        except (ValueError, TypeError):
            raise ValueError(
                "due_at must be a valid ISO 8601 datetime."
            )

    with get_connection() as conn:
        cursor = conn.execute("""
            INSERT INTO reminders
            (description, due_at, created_at)
            VALUES (?, ?, ?)
        """, (
            description.strip(),
            due_at,
            datetime.now().isoformat()
        ))

        return cursor.lastrowid


def get_pending_reminders():
    with get_connection() as conn:
        rows = conn.execute("""
            SELECT * FROM reminders
            WHERE completed = 0
            ORDER BY
                CASE WHEN due_at IS NULL THEN 1 ELSE 0 END,
                due_at ASC,
                id ASC
        """).fetchall()

    return [dict(row) for row in rows]


def get_upcoming_reminders():
    now = datetime.now().isoformat()

    with get_connection() as conn:
        rows = conn.execute("""
            SELECT * FROM reminders
            WHERE completed = 0
            AND due_at IS NOT NULL
            AND due_at >= ?
            ORDER BY due_at ASC
        """, (now,)).fetchall()

    return [dict(row) for row in rows]


def get_overdue_reminders():
    now = datetime.now().isoformat()

    with get_connection() as conn:
        rows = conn.execute("""
            SELECT * FROM reminders
            WHERE completed = 0
            AND due_at IS NOT NULL
            AND due_at < ?
            ORDER BY due_at ASC
        """, (now,)).fetchall()

    return [dict(row) for row in rows]


def complete_reminder(reminder_id):
    with get_connection() as conn:
        cursor = conn.execute("""
            UPDATE reminders
            SET completed = 1
            WHERE id = ? AND completed = 0
        """, (reminder_id,))

        return cursor.rowcount > 0


def delete_reminder(reminder_id):
    with get_connection() as conn:
        cursor = conn.execute("""
            DELETE FROM reminders
            WHERE id = ?
        """, (reminder_id,))

        return cursor.rowcount > 0


def get_all_reminders():
    with get_connection() as conn:
        rows = conn.execute("""
            SELECT * FROM reminders
            ORDER BY id DESC
        """).fetchall()

    return [dict(row) for row in rows]


initialize_tools()
