
import os
import time
from pathlib import Path
from faster_whisper import WhisperModel

MODEL_SIZE = os.getenv("WHISPER_MODEL_SIZE", "tiny.en")
DOWNLOAD_PATH = Path(__file__).resolve().parent.parent / "models" / "whisper"

_whisper = None


def get_whisper():
    global _whisper

    if _whisper is None:
        DOWNLOAD_PATH.mkdir(parents=True, exist_ok=True)

        _whisper = WhisperModel(
            MODEL_SIZE,
            device="cpu",
            compute_type="int8",
            download_root=str(DOWNLOAD_PATH)
        )

    return _whisper


def transcribe_audio(audio_path):
    if not audio_path:
        return {
            "text": "",
            "language": None,
            "duration": 0,
            "error": "No audio file provided."
        }

    audio_path = Path(audio_path)

    if not audio_path.is_file():
        return {
            "text": "",
            "language": None,
            "duration": 0,
            "error": "Audio file not found."
        }

    start = time.perf_counter()

    try:
        model = get_whisper()

        segments, info = model.transcribe(
            str(audio_path),
            beam_size=1,
            best_of=1,
            vad_filter=True,
            condition_on_previous_text=False
        )

        text = " ".join(
            segment.text.strip()
            for segment in segments
        ).strip()

        return {
            "text": text,
            "language": info.language,
            "duration": round(time.perf_counter() - start, 2),
            "error": None
        }

    except Exception as error:
        print(f"WHISPER ERROR: {type(error).__name__}: {error}")

        return {
            "text": "",
            "language": None,
            "duration": round(time.perf_counter() - start, 2),
            "error": str(error)
        }
