
import re
import tempfile
import wave
import threading
from pathlib import Path

from piper import PiperVoice


BASE_DIR = Path(__file__).resolve().parent.parent
VOICE_MODEL = BASE_DIR / "en_US-amy-medium.onnx"

_voice = None
_voice_lock = threading.Lock()


def get_voice():
    global _voice

    if _voice is None:
        if not VOICE_MODEL.is_file():
            raise FileNotFoundError(
                f"Piper model not found: {VOICE_MODEL}"
            )

        _voice = PiperVoice.load(str(VOICE_MODEL))

    return _voice


def clean_for_speech(text):
    if not text:
        return ""

    text = re.sub(r"```[\s\S]*?```", " ", text)
    text = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", text)
    text = re.sub(r"https?://\S+", " ", text)
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"[*_`#~]", "", text)
    text = re.sub(r"(?m)^\s*[-•]\s+", "", text)
    text = re.sub(r"\s+", " ", text)

    return text.strip()


def speak(text):
    text = clean_for_speech(text)

    if not text:
        return None

    with tempfile.NamedTemporaryFile(
        suffix=".wav",
        delete=False
    ) as audio:
        audio_path = Path(audio.name)

    try:
        voice = get_voice()

        # Prevent simultaneous synthesis on the same voice instance.
        with _voice_lock:
            with wave.open(str(audio_path), "wb") as wav_file:
                voice.synthesize_wav(text, wav_file)

        return audio_path

    except Exception as error:
        audio_path.unlink(missing_ok=True)
        print(
            f"PIPER ERROR: {type(error).__name__}: {error}"
        )
        raise
