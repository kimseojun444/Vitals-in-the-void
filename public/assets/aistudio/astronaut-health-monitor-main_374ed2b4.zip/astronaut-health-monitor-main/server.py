
import asyncio
import tempfile
from pathlib import Path

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse

from assistant.conversation import process_message, start_conversation
from assistant.voice_input import transcribe_audio
from assistant.voice_output import speak


BASE_DIR = Path(__file__).resolve().parent
HTML_FILE = BASE_DIR / "tars.html"

app = FastAPI(title="TARS Voice Server")


@app.get("/")
async def home():
    if not HTML_FILE.is_file():
        return HTMLResponse(
            "<h1>TARS interface not found.</h1>",
            status_code=404
        )

    return HTMLResponse(
        HTML_FILE.read_text(encoding="utf-8")
    )


async def send_status(websocket, message):
    await websocket.send_json({
        "type": "status",
        "message": message
    })



async def send_reply(websocket, text):
    audio_path = None

    try:
        audio_path = await asyncio.to_thread(speak, text)

        if audio_path:
            audio_bytes = await asyncio.to_thread(
                audio_path.read_bytes
            )

            # Send text metadata first.
            await websocket.send_json({
                "type": "reply",
                "text": text,
                "audio": True
            })

            # Send WAV as a binary frame.
            await websocket.send_bytes(audio_bytes)

        else:
            await websocket.send_json({
                "type": "reply",
                "text": text,
                "audio": False
            })

    finally:
        if audio_path:
            await asyncio.to_thread(
                audio_path.unlink,
                missing_ok=True
            )


@app.websocket("/voice")
async def voice_connection(websocket: WebSocket):
    await websocket.accept()

    print("TARS voice connection established.")

    try:
        await send_status(websocket, "TARS connected.")

        # Initial greeting
        greeting = start_conversation()

        try:
            await send_reply(websocket, greeting)
        except Exception as error:
            print("GREETING ERROR:", error)
            await websocket.send_json({
                "type": "reply",
                "text": greeting,
                "audio": None
            })

        # Main conversation loop
        while True:
            data = await websocket.receive_bytes()

            if not data:
                continue

            audio_path = None

            try:
                # Save incoming microphone audio
                with tempfile.NamedTemporaryFile(
                    suffix=".wav",
                    delete=False
                ) as audio_file:
                    audio_path = Path(audio_file.name)
                    audio_file.write(data)

                await send_status(
                    websocket,
                    "Listening..."
                )

                # Speech recognition
                result = await asyncio.to_thread(
                    transcribe_audio,
                    str(audio_path)
                )

                if result.get("error"):
                    print("TRANSCRIPTION ERROR:", result["error"])
                    await send_status(
                        websocket,
                        "I couldn't process that audio. Try again."
                    )
                    continue

                user_text = result.get("text", "").strip()

                if not user_text:
                    await send_status(
                        websocket,
                        "I didn't catch that. Try again."
                    )
                    continue

                print("USER:", user_text)

                await websocket.send_json({
                    "type": "transcript",
                    "text": user_text
                })

                # Gemini response
                await send_status(
                    websocket,
                    "TARS is thinking..."
                )

                answer = await asyncio.to_thread(
                    process_message,
                    user_text
                )

                print("TARS:", answer)

                # Piper speech generation
                await send_status(
                    websocket,
                    "TARS is responding..."
                )

                await send_reply(websocket, answer)

            except WebSocketDisconnect:
                raise

            except Exception as error:
                print(
                    f"CONVERSATION ERROR: "
                    f"{type(error).__name__}: {error}"
                )

                await websocket.send_json({
                    "type": "error",
                    "message": "Something went wrong. Let's try again."
                })

            finally:
                if audio_path:
                    audio_path.unlink(missing_ok=True)

    except WebSocketDisconnect:
        print("TARS connection closed.")

    except Exception as error:
        print(
            f"VOICE SERVER ERROR: "
            f"{type(error).__name__}: {error}"
        )

    finally:
        print("TARS voice session ended.")
