"""Input processing (voice/text parsing, fingertip pulse, skin photo, wearable files), live wearable simulation, sample crew."""
import io
import json
import math
import random
import re
from datetime import datetime, timedelta, timezone

import numpy as np
from PIL import Image

from . import reference as RF
from .model import DAY, Crew, clamp, new_crew_dict

# ---------------------------------------------------------------- voice / text
EXTRA_ALIAS = [("oxygen left", "eva_o2end"), ("o2 left", "eva_o2end"), ("suit oxygen", "eva_o2end"), ("oxygen remaining", "eva_o2end"),
               ("suit co2", "eva_co2"), ("inspired co2", "eva_co2"), ("peak heart rate", "eva_hrpct"), ("suit temperature", "eva_temp"),
               ("peak temperature", "eva_temp"), ("hand pain", "eva_hand"), ("finger pain", "eva_hand"), ("shoulder pain", "eva_shoulder"),
               ("nail lifting", "eva_nail"), ("prebreathe", "eva_prebreathe"), ("eva hours", "eva_hours7"), ("rest days", "eva_rest"),
               ("decompression", "eva_dcs"), ("dcs", "eva_dcs")]
ALIAS = sorted([(a, v["id"]) for v in RF.VARS for a in v.get("al", [])] + [("slept", "sleep"), ("hours of sleep", "sleep"), ("bp", "sbp"), ("pressure", "sbp")] + EXTRA_ALIAS,
               key=lambda x: -len(x[0]))
SYMW = [("headache", "headache"), ("blur", "blur"), ("congest", "congest"), ("stuffy", "congest"), ("chest pain", "chest"), ("palpitation", "chest"),
        ("dizz", "dizzy"), ("faint", "dizzy"), ("nause", "nausea"), ("vomit", "nausea"), ("rash", "rash"), ("itch", "rash"), ("fever", "fever"),
        ("chill", "fever"), ("flank", "flank"), ("blood in urine", "flank"), ("back pain", "back"), ("back hurts", "back"), ("backache", "back"), ("back ache", "back"), ("sore back", "back"),
        ("headache", "headache"), ("head hurts", "headache"), ("can't see", "blur"), ("blurry", "blur"), ("throw up", "nausea"), ("sick to my stomach", "nausea"),
        ("exhausted", "fatigue"), ("out of breath", "breath"), ("hard to breathe", "breath"), ("pins and needles", "numb"), ("tingl", "numb"), ("tired", "fatigue"), ("fatigue", "fatigue"),
        ("short of breath", "breath"), ("breathless", "breath"), ("neck", "neck"), ("hopeless", "low"), ("feeling low", "low"), ("sad", "low"),
        ("joint pain", "joint"), ("mottl", "mottle"), ("numb", "numb"), ("nail", "nails"), ("shoulder", "shoulder")]


def _name_aliases():
    """Aliases from variable names so lab reports and speech using full names are understood ('Hemoglobin 14.2')."""
    out = []
    for v in RF.VARS:
        if v["f"] == "calc":
            continue
        n = v["n"].lower()
        base = re.sub(r"\s*\(.*?\)", "", n).strip()
        cands = {base, n}
        for inner in re.findall(r"\((.*?)\)", n):
            if len(inner) >= 3 and not re.search(r"\d|/", inner):
                cands.add(inner.strip())
        for pre in ("serum ", "urinary ", "total ", "peak ", "fasting ", "absolute "):
            if base.startswith(pre):
                cands.add(base[len(pre):])
        for a in cands:
            if len(a) >= 3:
                out.append((a, v["id"]))
    return out


ALIAS_ALL = sorted(set(ALIAS) | set(_name_aliases()), key=lambda x: -len(x[0]))


def parse_utterance(txt, scope=None):
    """Find 'name … number' pairs (speech, typed text, OCR or document text). scope = allowed variable ids."""
    out, sy = [], set()
    t = " " + re.sub(r"(\d),(\d)", r"\1.\2", (txt or "").lower()) + " "

    def bp(m):
        out.extend([("sbp", float(m.group(1))), ("dbp", float(m.group(2)))])
        return " ; "
    if not scope or "sbp" in scope:
        t = re.sub(r"(?:blood pressure|bp)\D{0,12}?(\d{2,3})\s*(?:over|/|by)\s*(\d{2,3})", bp, t)

    def sl(m):
        out.append(("sleep", float(m.group(1))))
        return " ; "
    if not scope or "sleep" in scope:
        t = re.sub(r"(\d+(?:\.\d+)?)\s*(?:hours?|hrs?|h)\s*(?:of\s*)?sleep", sl, t)
    for a, vid in ALIAS_ALL:
        if scope and vid not in scope:
            continue
        def rep(m, vid=vid):
            if not any(o[0] == vid for o in out):
                out.append((vid, float(m.group(1))))
            return " ; "
        t = re.sub(r"\b" + re.escape(a) + r"\b[^\d;\n]{0,18}?(-?\d+(?:\.\d+)?)", rep, t)
    for w, k in SYMW:
        if w in t:
            sy.add(k)
    return {"vals": out, "sym": sorted(sy)}


# ---------------------------------------------------------------- fingertip pulse (signal sent from the browser)
def ppg(t, r):
    t, r = np.asarray(t, float), np.asarray(r, float)
    n = len(t)
    if n < 60 or t[-1] - t[0] < 6:
        return {"ok": False, "msg": "Too short: record at least 10 s."}
    dt = (t[-1] - t[0]) / n
    w = max(3, int(round(1 / dt)))
    k = np.ones(2 * w + 1) / (2 * w + 1)
    base = np.convolve(np.pad(r, w, mode="edge"), k, mode="valid")
    det = r - base
    sm = np.convolve(np.pad(det, 1, mode="edge"), np.ones(3) / 3, mode="valid")
    pk = []
    for i in range(1, n - 1):
        if sm[i] > 0 and sm[i] >= sm[i - 1] and sm[i] > sm[i + 1] and (not pk or t[i] - pk[-1] > 0.33):
            pk.append(t[i])
    if len(pk) < 4:
        return {"ok": False, "msg": "No clear pulse found. Cover lens and flash gently and hold still."}
    iv = np.diff(pk)
    mean = float(iv.mean())
    cv = float(iv.std() / mean)
    return {"ok": True, "hr": round(60 / mean), "beats": len(pk), "quality": "good" if cv < 0.12 else "fair" if cv < 0.25 else "poor",
            "wave": [round(float(x), 3) for x in sm[:: max(1, n // 300)]]}


# ---------------------------------------------------------------- skin photo erythema
def skin_index(data: bytes):
    img = Image.open(io.BytesIO(data)).convert("RGB")
    s = min(1.0, 400 / max(img.size))
    img = img.resize((max(1, int(img.width * s)), max(1, int(img.height * s))))
    a = np.asarray(img).astype(float)
    h, w = a.shape[:2]
    c = a[h // 4: 3 * h // 4, w // 4: 3 * w // 4]
    R, G = c[..., 0], c[..., 1]
    m = (R > 15) & (G > 15)
    return float((100 * np.log10(R[m] / G[m])).mean()) if m.any() else 0.0


# ---------------------------------------------------------------- wearable / device file import
def parse_wearable(text):
    text = (text or "").strip()
    rows = []
    if not text:
        return rows
    if text[0] in "[{":
        j = json.loads(text)
        for o in (j if isinstance(j, list) else j.get("data", [])):
            rows.append((o.get("metric") or o.get("id") or o.get("type"), o.get("value"), o.get("time", o.get("day", o.get("date")))))
    else:
        for ln in text.splitlines():
            p = [x.strip() for x in re.split(r"[,;\t]", ln)]
            if len(p) >= 2 and p[0].lower() != "metric":
                rows.append((p[0], p[1], p[2] if len(p) > 2 else None))
    return rows


def map_metric(n):
    n = str(n or "").lower().strip()
    if n in RF.VM:
        return n
    for a, v in ALIAS:
        if a == n:
            return v
    for v in RF.VARS:
        if v["n"].lower() == n:
            return v["id"]
    return None


# ---------------------------------------------------------------- live wearable simulation
LIVEV = ["hr", "hrv", "spo2", "ctemp", "glu", "shift", "dose"]
NOISE = {"hr": 3, "hrv": 4, "spo2": 0.6, "ctemp": 0.08, "glu": 4, "shift": 0.05, "dose": 0.05}


def live_values(c: Crew, d, inject):
    out = {}
    for vid in LIVEV:
        E = c.expected(vid, d)
        x = E + random.gauss(0, 1) * (E * NOISE["dose"] if vid == "dose" else NOISE[vid])
        if inject == "hypox" and vid == "spo2":
            x = 88 + random.gauss(0, 1)
        if inject == "mild_hr" and vid == "hr":
            x = E + 2.4 * RF.VM["hr"]["tol"] + random.gauss(0, 1)
        if inject == "tachy" and vid == "hr":
            x = 138 + random.gauss(0, 3)
        if inject == "fever" and vid == "ctemp":
            x = 39.5
        if inject == "spe" and vid == "dose":
            x = E * 12
        out[vid] = round(x, RF.VM[vid].get("dp", 1) + 1)
    return out


# ---------------------------------------------------------------- sample crew (simulated, clearly marked)
def _seeded(seed):
    rnd = random.Random(seed)
    return rnd, (lambda: rnd.gauss(0, 1))


def make_sample_crew(store):
    rnd, gauss = _seeded(20261114)
    launch = (datetime.now(timezone.utc) - timedelta(days=112.4)).isoformat()
    people = [dict(name="Aditi Rao", role="Commander", age=44, sex="F", weight=64, hand=19.5, At=0.82),
              dict(name="Mateo Silva", role="Flight engineer", age=47, sex="M", weight=79, hand=23.4, At=1.3),
              dict(name="Lena Okafor", role="Mission specialist", age=39, sex="F", weight=66, hand=19.0, At=1.0)]
    made = []
    for p in people:
        At = p.pop("At")
        d = new_crew_dict(mission="iss", launch=launch, A0=1, sample=True, **p)
        base = {}
        for v in RF.VARS:
            if v["f"] in ("calc", "eva") or v.get("env"):
                continue
            b = v["b"]
            if v["id"] not in ("amsler", "ijvf", "viral", "shift", "vis", "dlmo"):
                b = v["b"] + 0.7 * v["tol"] * clamp(gauss(), -2, 2)
            base[v["id"]] = round(b, max(v.get("dp", 1), 2))
        base["mass"] = p["weight"]
        base["kcal"] = 2500 if p["sex"] == "F" else 2900
        d["base"] = base
        store.db.x("INSERT OR REPLACE INTO crew VALUES (?,?)", (d["id"], json.dumps(d)))
        c = Crew(store, d)
        store.crew[c.id] = c
        rt = {v["id"]: clamp(1 + 0.2 * gauss(), 0.6, 1.5) for v in RF.VARS}
        rt["exer"] = rt["kcal"] = 1
        if At < 1:
            rt.update(kcal=0.5, sleep=0.7, ijv=0.9)
        N = int(math.floor(c.now_day()))
        name = p["name"]

        def extra(vid, dd):
            e = 0.0
            if name == "Mateo Silva":
                e = {"onsd": 0.012 * (dd - 55) if dd > 55 else 0, "trt": 0.5 * (dd - 55) if dd > 55 else 0, "vis": 0.012 * (dd - 65) if dd > 65 else 0,
                     "iop": 0.06 * (dd - 70) if dd > 70 else 0, "sleep": -1.1 if dd > 80 else 0, "pvt": 45 if dd > 80 else 0,
                     "mood": -1.4 if dd > 85 else 0, "amsler": 1 if dd > 104 else 0}.get(vid, 0)
            if name == "Lena Okafor":
                e = {"ctx": 0.25 if dd > 30 else 0, "ntx": 25 if dd > 30 else 0, "ucal": 95 if dd > 40 else 0, "ijvf": 1 if dd > 100 else 0,
                     "kcal": -350 if dd > 60 else 0, "bmd": -0.012 * (dd - 30) if dd > 30 else 0}.get(vid, 0)
            if vid == "dose" and 94 <= dd < 95:
                e = 7.5
            return e

        rows = []
        U, X = c.series()
        for dd in range(N + 1):
            for v in RF.VARS:
                if v["f"] in ("calc", "eva"):
                    continue
                per = {"cont": 1, "daily": 1, "d2": 2, "d3": 3, "weekly": 7}.get(v["f"], 7)
                if per > 1 and dd % per != per - 1:
                    continue
                if v["f"] == "daily" and rnd.random() < 0.06:
                    continue
                vid = v["id"]
                b = c.B(vid)
                E = RF.ENVS[c.env_at(dd)]["dose"] if v.get("env") else b + rt[vid] * (U if v.get("gs", 1) else X)[dd] * Crew.delta_at(v, b, dd, At)
                x = E + extra(vid, dd) + clamp(gauss(), -2.2, 2.2) * (0.08 * E if v.get("env") else (0.45 if v["f"] == "daily" else 0.6) * v["tol"])
                if vid in ("amsler", "ijvf"):
                    x = round(clamp(E + extra(vid, dd), 1 if vid == "ijvf" else 0, 3))
                if vid == "viral":
                    x = clamp(1.5 + gauss(), 0.5, 3.2) if rnd.random() < (0.45 if dd > 30 else 0.2) else 0
                if vid == "exer":
                    x = clamp(x, 30, 150)
                if vid not in ("dlmo", "vis") and x < 0:
                    x = 0.0
                if vid in ("mood", "stress"):
                    x = clamp(round(x), 1, 10)
                off = 0.3 if v["f"] == "cont" else 0.35 if v["f"] == "daily" else 0.4
                rows.append((c.id, vid, round(dd + off, 4), round(x, max(v.get("dp", 1), 2)), "a" if v["inv"] else "d"))
            if name == "Mateo Silva" and dd > 98 and dd % 3 == 0:
                rows.append((c.id, "sym_headache", dd + 0.5, 1, "d"))
            if name == "Mateo Silva" and dd > 104:
                rows.append((c.id, "sym_blur", dd + 0.5, 1, "d"))
        # two spacewalks for the sample: day 60 (Rao, nominal) and day 108 (Silva, hand injury)
        if name == "Aditi Rao":
            for vid, x in dict(eva_prebreathe=100, eva_co2=3.1, eva_hrpct=71, eva_temp=37.6, eva_o2end=38, eva_hand=1, eva_nail=0, eva_shoulder=1, eva_dcs=0, eva_hours7=6.8, eva_rest=30).items():
                rows.append((c.id, vid, 60.6, x, "d"))
        if name == "Mateo Silva":
            for vid, x in dict(eva_prebreathe=100, eva_co2=5.2, eva_hrpct=82, eva_temp=38.1, eva_o2end=24, eva_hand=4, eva_nail=1, eva_shoulder=2, eva_dcs=0, eva_hours7=7.1, eva_rest=48).items():
                rows.append((c.id, vid, 108.6, x, "d"))
        store.db.xmany("INSERT INTO records (crew_id,var,day,value,src) VALUES (?,?,?,?,?)", rows)
        made.append(c)
    # reload records with ids, then compute formulas day by day
    for c in made:
        store.recs[c.id] = [[rid, var, day, val, src] for rid, var, day, val, src in
                            store.db.q("SELECT id, var, day, value, src FROM records WHERE crew_id=? ORDER BY day", (c.id,))]
        c.reset()
    store.bulk = []
    for c in made:
        for dd in sorted({r[2] for r in c.recs}):
            c.derive(dd)
    rows = [(cid, var, day, val, src) for _, cid, var, day, val, src in store.bulk]
    store.bulk = None
    store.db.xmany("INSERT INTO records (crew_id,var,day,value,src) VALUES (?,?,?,?,?)", rows)
    for c in made:
        store.recs[c.id] = [[rid, var, day, val, src] for rid, var, day, val, src in
                            store.db.q("SELECT id, var, day, value, src FROM records WHERE crew_id=? ORDER BY day", (c.id,))]
        c.reset()
    return made


# ---------------------------------------------------------------- simulated assessment (demonstration)
def simulate_panel(c: Crew, d, panels, scenario="typical"):
    """Plausible values for the chosen panels: the astronaut's expected value plus normal variation.
    scenario 'issues' pushes two measures off their trajectory so the warning/alert logic can be seen working."""
    ids = []
    for p in RF.PANELS:
        if (not panels and p["id"] != "eva") or p["id"] in panels:
            ids += [v for v in p["v"] if v not in ids]
    out = {}
    for vid in ids:
        v = RF.VM[vid]
        E, t = c.expected(vid, d), c.tol(vid, d)
        x = E + clamp(random.gauss(0, 0.7), -1.6, 1.6) * t
        if vid == "eva_prebreathe":
            x = 100
        if vid in ("eva_nail", "eva_dcs", "amsler"):
            x = 0
        out[vid] = x
    if scenario == "issues" and ids:
        rnd = random.Random()
        pick = [i for i in ids if RF.VM[i]["dir"] != "lo" and not RF.VM[i].get("env") and i not in ("eva_dcs", "eva_prebreathe")][:]
        rnd.shuffle(pick)
        for k, vid in enumerate(pick[:2]):
            E, t = c.expected(vid, d), c.tol(vid, d)
            out[vid] = E + (2.5 if k == 0 else 3.6) * t
    for vid in list(out):
        v = RF.VM[vid]
        out[vid] = round(max(0.0, out[vid]) if vid not in ("dlmo", "vis") else out[vid], max(v.get("dp", 1), 2))
    return out


# ---------------------------------------------------------------- values from any input (speech text, photo, file)
def ocr_image(data: bytes):
    try:
        import pytesseract
        img = Image.open(io.BytesIO(data)).convert("L")
        if max(img.size) < 1400:
            s = 1400 / max(img.size)
            img = img.resize((int(img.width * s), int(img.height * s)))
        return pytesseract.image_to_string(img), None
    except Exception as e:
        return "", "Reading photos needs the free Tesseract OCR program installed (see README)." if "tesseract" in str(e).lower() else f"Could not read the photo ({e.__class__.__name__})."


def file_text_and_rows(filename, data: bytes):
    fn = filename.lower()
    rows, text = [], ""
    if fn.endswith((".csv", ".tsv", ".txt")):
        text = data.decode("utf-8", "replace")
        rows = [re.split(r"[,;\t]", ln) for ln in text.splitlines()]
    elif fn.endswith(".json"):
        try:
            j = json.loads(data.decode("utf-8", "replace"))
            items = j if isinstance(j, list) else j.get("data", [j]) if isinstance(j, dict) else []
            for o in items:
                if isinstance(o, dict):
                    if "value" in o:
                        rows.append([o.get("metric") or o.get("id") or o.get("name"), o["value"]])
                    else:
                        rows += [[k, v] for k, v in o.items()]
        except ValueError:
            pass
    elif fn.endswith((".xlsx", ".xlsm")):
        import openpyxl
        wb = openpyxl.load_workbook(io.BytesIO(data), data_only=True)
        for ws in wb:
            rows += [["" if x is None else x for x in r] for r in ws.iter_rows(values_only=True)]
    elif fn.endswith(".pdf"):
        import pdfplumber
        with pdfplumber.open(io.BytesIO(data)) as pdf:
            for p in pdf.pages:
                for t in p.extract_tables() or []:
                    rows += t
                text += (p.extract_text() or "") + "\n"
    elif fn.endswith(".docx"):
        import docx
        d = docx.Document(io.BytesIO(data))
        for t in d.tables:
            rows += [[c.text for c in r.cells] for r in t.rows]
        text = "\n".join(p.text for p in d.paragraphs)
    return text, rows


def values_from_rows(rows, scope=None):
    out = {}
    rows = [[str(c).strip() if c is not None else "" for c in r] for r in rows if r]
    # layout A: one measure per row (name, value, …)
    for r in rows:
        if len(r) < 2:
            continue
        vid = map_metric(r[0])
        if not vid:
            hit = parse_utterance(r[0] + " 0", scope)["vals"]
            vid = hit[0][0] if hit else None
        if vid and (not scope or vid in scope):
            for cell in r[1:]:
                try:
                    out.setdefault(vid, float(re.sub(r"[^\d.\-]", "", cell)))
                    break
                except ValueError:
                    continue
    # layout B: header row of names, values below
    if not out and len(rows) >= 2:
        head = [map_metric(h) or (parse_utterance(h + " 0", scope)["vals"] or [[None]])[0][0] for h in rows[0]]
        for k, vid in enumerate(head):
            if vid and (not scope or vid in scope) and k < len(rows[1]):
                try:
                    out[vid] = float(re.sub(r"[^\d.\-]", "", rows[1][k]))
                except ValueError:
                    pass
    return out


def extract_values(text=None, filename=None, data=None, scope=None):
    note = ""
    vals = {}
    if data is not None:
        fn = (filename or "").lower()
        if fn.endswith((".png", ".jpg", ".jpeg", ".webp", ".bmp", ".heic", ".tif", ".tiff")) or not fn:
            from .ai import hooks as AI
            ai = AI.read_device_photo(data, scope or [])
            if ai:
                vals = {o["id"]: o["value"] for o in ai}
                note = "Read by AI"
            else:
                text, note = ocr_image(data)
                if not note:
                    note = "Read from the photo with OCR: check every value."
        else:
            text, rows = file_text_and_rows(filename, data)
            vals = values_from_rows(rows, scope)
    if text and not vals:
        vals = {k: v for k, v in parse_utterance(text, scope)["vals"]}
    if text:
        sym = parse_utterance(text)["sym"]
    else:
        sym = []
    return {"vals": [{"v": k, "n": RF.VM[k]["n"], "u": RF.VM[k]["u"], "value": v} for k, v in vals.items() if k in RF.VM],
            "sym": sym, "note": note, "text": (text or "")[:2000]}
