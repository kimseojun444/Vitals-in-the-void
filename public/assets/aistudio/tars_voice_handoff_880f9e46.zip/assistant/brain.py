import ollama

from assistant.personality import get_personality
from assistant.memory import (
    search_memories,
    get_recent_conversation,
    save_message
)

MODEL = "qwen2.5:3b"


def build_context(user_message):
    memories = search_memories(user_message)

    memory_context = "\n".join(
        f"- {memory['category']}: {memory['content']}"
        for memory in memories
    )

    history = get_recent_conversation(6)

    messages = [
        {
            "role": "system",
            "content": (
                get_personality()
                + "\n\nRELEVANT MEMORIES:\n"
                + (memory_context or "No relevant memories.")
                + """

IMPORTANT RESPONSE RULES:
- Always respond in English unless the user explicitly requests another language.
- Respond directly to the person speaking to you.
- Never describe your thought process.
- Never narrate what the user is asking.
- Never explain what you are about to say.
- Never output internal analysis, plans or reasoning.
- Speak as TARS, naturally and conversationally.
- Keep ordinary spoken replies concise.
- Do not repeatedly mention your appearance or species.
- Never generate random or unrelated information.
"""
            )
        }
    ]

    for row in history:
        if row["message"].strip():
            messages.append({
                "role": row["role"],
                "content": row["message"]
            })

    messages.append({
        "role": "user",
        "content": user_message.strip()
    })

    return messages


def think(user_message):
    if not user_message or not user_message.strip():
        return "I'm listening. What's up?"

    user_message = user_message.strip()
    messages = build_context(user_message)

    response = ollama.chat(
        model=MODEL,
        messages=messages,
        think=False,
        options={
            "num_predict": 100,
            "num_ctx": 2048,
            "temperature": 0.7
        }
    )

    answer = response.message.content.strip()

    if not answer:
        return "Hmm, I seem to have lost my words. Try asking me again?"

    save_message("user", user_message)
    save_message("assistant", answer)

    return answer