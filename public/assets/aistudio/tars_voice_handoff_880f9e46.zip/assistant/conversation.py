
from assistant.brain import think
from assistant.memory import save_memory


def process_message(user_message):
    if not user_message or not user_message.strip():
        return "I'm listening. Tell me what's on your mind."

    response = think(user_message.strip())

    return response


def remember(category, information):
    if not category or not information:
        return False

    save_memory(category.strip(), information.strip())
    return True


def start_conversation():
    return (
        "V² crew systems online. "
        "TARS reporting for duty! "
        "Your favourite feline crew member is here. "
        "How's my astronaut doing today?"
    )
