
import sqlite3
from pathlib import Path
from datetime import datetime

DB_PATH = Path(__file__).parent / "tars_memory.db"


def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def initialize_memory():
    with get_connection() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS memories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                category TEXT NOT NULL,
                content TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
        """)

        conn.execute("""
            CREATE TABLE IF NOT EXISTS conversations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                role TEXT NOT NULL,
                message TEXT NOT NULL,
                timestamp TEXT NOT NULL
            )
        """)


def save_memory(category, content):
    with get_connection() as conn:
        conn.execute(
            "INSERT INTO memories (category, content, created_at) VALUES (?, ?, ?)",
            (category, content, datetime.now().isoformat())
        )


def search_memories(query, limit=10):
    with get_connection() as conn:
        return conn.execute(
            "SELECT * FROM memories WHERE content LIKE ? ORDER BY id DESC LIMIT ?",
            (f"%{query}%", limit)
        ).fetchall()


def get_all_memories(limit=50):
    with get_connection() as conn:
        return conn.execute(
            "SELECT * FROM memories ORDER BY id DESC LIMIT ?",
            (limit,)
        ).fetchall()


def save_message(role, message):
    with get_connection() as conn:
        conn.execute(
            "INSERT INTO conversations (role, message, timestamp) VALUES (?, ?, ?)",
            (role, message, datetime.now().isoformat())
        )


def get_recent_conversation(limit=20):
    with get_connection() as conn:
        rows = conn.execute(
            "SELECT role, message FROM conversations ORDER BY id DESC LIMIT ?",
            (limit,)
        ).fetchall()

    return list(reversed(rows))


def clear_conversation_history():
    with get_connection() as conn:
        conn.execute("DELETE FROM conversations")


initialize_memory()
