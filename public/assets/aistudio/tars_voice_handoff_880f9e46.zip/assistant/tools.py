
from datetime import datetime
from assistant.memory import (
    get_connection,
    save_memory,
    search_memories
)


def initialize_tools():
    with get_connection() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS reminders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                description TEXT NOT NULL,
                due_at TEXT,
                completed INTEGER DEFAULT 0,
                created_at TEXT NOT NULL
            )
        """)


def save_note(note, category="note"):
    if not note or not note.strip():
        return False

    save_memory(category, note.strip())
    return True


def find_information(query):
    if not query or not query.strip():
        return []

    return [
        dict(row) for row in search_memories(query.strip())
    ]


def create_reminder(description, due_at=None):
    if not description or not description.strip():
        return None

    with get_connection() as conn:
        cursor = conn.execute("""
            INSERT INTO reminders
            (description, due_at, created_at)
            VALUES (?, ?, ?)
        """, (
            description.strip(),
            due_at,
            datetime.now().isoformat()
        ))

        return cursor.lastrowid


def get_pending_reminders():
    with get_connection() as conn:
        rows = conn.execute("""
            SELECT * FROM reminders
            WHERE completed = 0
            ORDER BY due_at ASC, id ASC
        """).fetchall()

    return [dict(row) for row in rows]


def complete_reminder(reminder_id):
    with get_connection() as conn:
        cursor = conn.execute("""
            UPDATE reminders
            SET completed = 1
            WHERE id = ? AND completed = 0
        """, (reminder_id,))

        return cursor.rowcount > 0


initialize_tools()
