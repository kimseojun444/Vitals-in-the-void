from faster_whisper import WhisperModel

MODEL_PATH = "small"
DOWNLOAD_PATH = "models/whisper"

_whisper = None


def get_whisper():
    global _whisper

    if _whisper is None:
        _whisper = WhisperModel(
            MODEL_PATH,
            device="cpu",
            compute_type="int8",
            download_root=DOWNLOAD_PATH
        )

    return _whisper


def transcribe_audio(audio_path):
    model = get_whisper()

    segments, info = model.transcribe(
        audio_path,
        beam_size=1,
        vad_filter=True
    )

    text = " ".join(
        segment.text.strip() for segment in segments
    ).strip()

    return {
        "text": text,
        "language": info.language
    }