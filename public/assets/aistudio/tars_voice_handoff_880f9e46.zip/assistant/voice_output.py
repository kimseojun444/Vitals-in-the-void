import subprocess
import tempfile
import re
from pathlib import Path

VOICE_MODEL = Path("en_US-amy-medium.onnx")


def clean_for_speech(text):
    # Remove code blocks
    text = re.sub(r'```.*?```', '', text, flags=re.DOTALL)

    # Keep link text, remove URLs
    text = re.sub(r'\[([^\]]+)\]\([^)]+\)', r'\1', text)

    # Remove Markdown formatting symbols
    text = re.sub(r'[*_`#~]', '', text)

    # Remove bullet symbols
    text = re.sub(r'(?m)^\s*[-•]\s+', '', text)

    # Clean unnecessary spaces
    text = re.sub(r'\s+', ' ', text).strip()

    return text


def speak(text):
    if not text or not text.strip():
        return None

    text = clean_for_speech(text)

    if not text:
        return None

    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as audio:
        audio_path = Path(audio.name)

    try:
        subprocess.run(
            [
                "python", "-m", "piper",
                "--model", str(VOICE_MODEL),
                "--output_file", str(audio_path)
            ],
            input=text,
            text=True,
            check=True
        )

        return audio_path

    except Exception:
        audio_path.unlink(missing_ok=True)
        raise