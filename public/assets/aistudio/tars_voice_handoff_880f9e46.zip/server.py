
import asyncio
import json
import tempfile
import os
from pathlib import Path

import numpy as np
import soundfile as sf
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse

from assistant.conversation import process_message, start_conversation
from assistant.voice_input import transcribe_audio
from assistant.voice_output import speak

app = FastAPI(title="TARS Voice Server")

HTML_FILE = Path("tars.html")


@app.get("/")
async def home():
    if not HTML_FILE.exists():
        return HTMLResponse("<h1>TARS interface not found.</h1>", status_code=404)
    return HTMLResponse(HTML_FILE.read_text(encoding="utf-8"))


@app.websocket("/voice")
async def voice_connection(websocket: WebSocket):
    await websocket.accept()
    await websocket.send_json({
        "type": "status",
        "message": "TARS connected."
    })

    greeting = start_conversation()
    greeting_path = await asyncio.to_thread(speak, greeting)

    if greeting_path:
        audio_bytes = await asyncio.to_thread(greeting_path.read_bytes)
        await websocket.send_json({
            "type": "reply",
            "text": greeting,
            "audio": audio_bytes.hex()
        })
        await asyncio.to_thread(greeting_path.unlink, missing_ok=True)

    try:
        while True:
            data = await websocket.receive_bytes()

            if not data:
                continue

            with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
                audio_path = Path(f.name)
                f.write(data)

            try:
                result = await asyncio.to_thread(
                    transcribe_audio, str(audio_path)
                )
                user_text = result["text"].strip()

            finally:
                audio_path.unlink(missing_ok=True)

            if not user_text:
                await websocket.send_json({
                    "type": "status",
                    "message": "I didn't catch that. Try again."
                })
                continue

            await websocket.send_json({
                "type": "transcript",
                "text": user_text
            })

            answer = await asyncio.to_thread(process_message, user_text)

            audio_path = await asyncio.to_thread(speak, answer)

            if audio_path:
                audio_bytes = await asyncio.to_thread(audio_path.read_bytes)
                await websocket.send_json({
                    "type": "reply",
                    "text": answer,
                    "audio": audio_bytes.hex()
                })
                await asyncio.to_thread(audio_path.unlink, missing_ok=True)
            else:
                await websocket.send_json({
                    "type": "reply",
                    "text": answer,
                    "audio": None
                })

    except WebSocketDisconnect:
        print("TARS connection closed.")
    except Exception as error:
        print("Voice server error:", error)
        try:
            await websocket.send_json({
                "type": "error",
                "message": str(error)
            })
        except Exception:
            pass
