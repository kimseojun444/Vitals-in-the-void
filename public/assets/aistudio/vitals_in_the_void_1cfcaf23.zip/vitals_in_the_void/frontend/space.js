/* Vitals in the Void — slow, minimal, interactive space background.
   Three parallax star layers that lean gently toward the cursor, two drifting nebula glows,
   a faint ringed planet with an orbiting satellite, and a rare shooting star.
   Pauses when the tab is hidden; draws one still frame when the user prefers reduced motion. */
(() => {
  const cv = document.getElementById('space'); if (!cv) return;
  const cx = cv.getContext('2d');
  const still = matchMedia('(prefers-reduced-motion: reduce)').matches;
  let W = 0, H = 0, DPR = 1, stars = [], mx = 0, my = 0, tx = 0, ty = 0, shoot = null, last = performance.now(), run = true, t = 0;
  const rnd = (a, b) => a + Math.random() * (b - a);

  function size() {
    DPR = Math.min(2, devicePixelRatio || 1); W = innerWidth; H = innerHeight;
    cv.width = W * DPR; cv.height = H * DPR; cv.style.width = W + 'px'; cv.style.height = H + 'px';
    cx.setTransform(DPR, 0, 0, DPR, 0, 0);
    const n = Math.round(Math.min(260, W * H / 6500));
    stars = Array.from({ length: n }, () => {
      const z = Math.random();               // depth 0 (far) .. 1 (near)
      return { x: rnd(0, W), y: rnd(0, H), z, r: .4 + z * 1.3, a: .25 + z * .55, tw: rnd(0, 6.28), ts: rnd(.4, 1.4),
        hue: Math.random() < .12 ? 'rgba(196,155,255,' : Math.random() < .1 ? 'rgba(150,190,255,' : 'rgba(255,255,255,' };
    });
  }

  function nebula(x, y, r, c) {
    const g = cx.createRadialGradient(x, y, 0, x, y, r);
    g.addColorStop(0, c); g.addColorStop(1, 'rgba(0,0,0,0)');
    cx.fillStyle = g; cx.fillRect(x - r, y - r, r * 2, r * 2);
  }

  function planet(px, py) {
    const R = Math.min(W, H) * .085;
    // ring (back half)
    cx.save(); cx.translate(px, py); cx.rotate(-.35);
    cx.strokeStyle = 'rgba(184,167,255,.16)'; cx.lineWidth = 1.2;
    cx.beginPath(); cx.ellipse(0, 0, R * 2.1, R * .55, 0, Math.PI, Math.PI * 2); cx.stroke();
    cx.restore();
    // body
    const g = cx.createRadialGradient(px - R * .4, py - R * .4, R * .1, px, py, R);
    g.addColorStop(0, 'rgba(120,96,230,.35)'); g.addColorStop(1, 'rgba(40,28,90,.22)');
    cx.fillStyle = g; cx.beginPath(); cx.arc(px, py, R, 0, Math.PI * 2); cx.fill();
    cx.strokeStyle = 'rgba(184,167,255,.22)'; cx.lineWidth = 1; cx.stroke();
    // ring (front half)
    cx.save(); cx.translate(px, py); cx.rotate(-.35);
    cx.strokeStyle = 'rgba(184,167,255,.26)'; cx.lineWidth = 1.2;
    cx.beginPath(); cx.ellipse(0, 0, R * 2.1, R * .55, 0, 0, Math.PI); cx.stroke();
    cx.restore();
    // orbit + satellite
    const oa = R * 3.4, ob = R * 1.25, ang = t * .045;
    cx.save(); cx.translate(px, py); cx.rotate(.18);
    cx.setLineDash([2, 7]); cx.strokeStyle = 'rgba(184,167,255,.12)'; cx.beginPath(); cx.ellipse(0, 0, oa, ob, 0, 0, Math.PI * 2); cx.stroke(); cx.setLineDash([]);
    const sx = Math.cos(ang) * oa, sy = Math.sin(ang) * ob, behind = Math.sin(ang) < 0 && Math.abs(sx) < R;
    if (!behind) {
      cx.fillStyle = 'rgba(230,222,255,.85)'; cx.fillRect(sx - 2, sy - 1.5, 4, 3);
      cx.fillStyle = 'rgba(122,167,255,.55)'; cx.fillRect(sx - 9, sy - 1, 5, 2); cx.fillRect(sx + 4, sy - 1, 5, 2);
      if ((t * 1.2) % 3 < .15) { cx.fillStyle = 'rgba(239,91,91,.9)'; cx.beginPath(); cx.arc(sx, sy - 3, 1.3, 0, 7); cx.fill(); }
    }
    cx.restore();
  }

  function frame(now) {
    const dt = Math.min(.05, (now - last) / 1000); last = now; t += dt;
    tx += (mx - tx) * .025; ty += (my - ty) * .025;   // eased cursor parallax
    cx.clearRect(0, 0, W, H);
    // drifting nebulae
    nebula(W * (.78 + .05 * Math.sin(t * .03)) + tx * 10, H * (.12 + .04 * Math.cos(t * .025)) + ty * 8, Math.max(W, H) * .55, 'rgba(122,80,255,.12)');
    nebula(W * (.08 + .04 * Math.cos(t * .02)) + tx * 6, H * (.95 + .03 * Math.sin(t * .03)) + ty * 6, Math.max(W, H) * .45, 'rgba(91,63,214,.10)');
    nebula(W * (.45 + .06 * Math.sin(t * .015)), H * .55, Math.max(W, H) * .35, 'rgba(196,155,255,.035)');
    // stars
    for (const s of stars) {
      s.x -= dt * (1.5 + s.z * 5); if (s.x < -4) { s.x = W + 4; s.y = rnd(0, H); }
      const x = s.x + tx * s.z * 26, y = s.y + ty * s.z * 18;
      const a = s.a * (.7 + .3 * Math.sin(s.tw + t * s.ts));
      cx.fillStyle = s.hue + a + ')'; cx.beginPath(); cx.arc(x, y, s.r, 0, 7); cx.fill();
    }
    planet(W * .86 + tx * 14, H * .8 + ty * 10);
    // rare shooting star
    if (!shoot && Math.random() < dt / 14) shoot = { x: rnd(W * .1, W * .9), y: rnd(0, H * .4), vx: rnd(-520, -320), vy: rnd(120, 220), life: 1 };
    if (shoot) {
      const s = shoot; s.x += s.vx * dt; s.y += s.vy * dt; s.life -= dt * 1.1;
      const g = cx.createLinearGradient(s.x, s.y, s.x - s.vx * .18, s.y - s.vy * .18);
      g.addColorStop(0, `rgba(255,255,255,${.8 * s.life})`); g.addColorStop(1, 'rgba(255,255,255,0)');
      cx.strokeStyle = g; cx.lineWidth = 1.4; cx.beginPath(); cx.moveTo(s.x, s.y); cx.lineTo(s.x - s.vx * .18, s.y - s.vy * .18); cx.stroke();
      if (s.life <= 0) shoot = null;
    }
    if (run && !still) requestAnimationFrame(frame);
  }

  addEventListener('resize', () => { size(); if (still) frame(performance.now()); });
  addEventListener('pointermove', e => { mx = e.clientX / W - .5; my = e.clientY / H - .5; }, { passive: true });
  document.addEventListener('visibilitychange', () => {
    run = !document.hidden;
    if (run && !still) { last = performance.now(); requestAnimationFrame(frame); }
  });
  size(); requestAnimationFrame(frame);
})();
